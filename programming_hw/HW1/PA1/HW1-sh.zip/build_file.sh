#!/bin/bash
rm -rf HW1
tar -xvf HW1assignment.tar && mv Assignment1 HW1
cd HW1

function contains(){ 
	name=$1[@]
	file=$2
	fileList=("${!name}")

    for i in "${fileList[@]}" ; do
    	if [[ $file == $i ]] ; then 
        	echo "1"
        	return 1 
        fi 
    done 
    echo "0"
    return 0
}


direction=('d' 'e' 'n' 'ne' 's' 'se' 'sw' 'w' 'nw' 'u')
hiddenDirection=('.d' '.e' '.n' '.ne' '.s' '.se' '.sw' '.w' '.nw' '.u')
items=('key' 'wax' 'lamp' 'paper' 'shovel' 'lifepreserver' 'weight' 'button' 'floppy_disk' 'wax_statuette' 'dial' 'congratulations_sign')


while read line
do
    name=$line
    name=$(echo $name | awk -F' ' '{print $2}')
    file=$(echo $name | awk -F'/' '{print $NF}')

 	 
 	if [[ "$(contains direction "$file")" == "1" || "$(contains hiddenDirection "$file")" == "1" ]]; then 
		#echo "link ->"$name
        if [[ ! -h $name ]]; then
           ln -s . $name 
        fi
        #continue
    elif [[ $file == "description" ]]; then
    	#echo "touch ->"$file
        if [[ ! -f $name ]]; then
           touch $name 
        fi 
        #continue
   	elif [[ "$(contains items "$file")" == "1"  ]]; then
   		#echo "item file -> "$file
   		if [[ ! -f $name ]]; then
           touch $name 
        fi  
        #continue 
    else
        #echo "mkdir -> "$file
    	if [[ ! -d $name && ! -f $name ]]; then 
            mkdir $name 
        fi
        #continue
    fi  
done < 'ExpectedResultOfFind'
cd Receiving_room
unlink e
ln -s Hallway e
cd Hallway
unlink e
ln -s Sauna e
unlink n
ln -s Hallway n
cd Sauna
unlink w
ln -s .. w
cd ../Hallway
unlink e 
ln -s Weightroom e 
unlink s
ln -s .. s
cd Weightroom
unlink w
ln -s ../ w 
unlink d
ln -s Maze1 d
cd ../../../../.Maze2/
unlink .u  
ln -s Maze3 .u
cd Maze3
unlink .se
ln -s  Maze4 .se 
unlink .d
ln -s .. .d 
unlink .e
ln -s .. .e
unlink .s 
ln -s .. .s
cd Maze4
unlink .d
ln -s Maze5 .d 
cd Maze5
unlink .nw
ln -s Maze6 .nw
unlink .se
ln -s Maze4 .se
cd Maze6
unlink .ne
ln -s ../../../../../Receiving_room/Hallway/Hallway/Weightroom .ne
unlink .nw
ln -s Reception_area .nw
unlink .d
ln -s ../../../../ .d 
unlink .e
ln -s ../../../../ .e
unlink .n
ln -s ../../../../ .n
unlink .s
ln -s ../../../../ .s
unlink .w
ln -s ../../../../ .w
unlink .se
ln -s ../../../../ .se
unlink .sw
ln -s ../../../../ .sw
cd Reception_area
unlink se
ln -s ../ se
unlink s
ln -s Healthclub_front s
cd Healthclub_front 
unlink s
ln -s Northern_lakefront s
cd Northern_lakefront
unlink n
ln -s .. n   
unlink s
ln -s Southern_lakefront s
cd Southern_lakefront
unlink n
ln -s .. n   
unlink s
ln -s Cave_entrance s
cd ~/HW1
cp descriptions/.Maze2.description ./.Maze2/description
cp descriptions/Cave_entrance.description .Maze2/Maze3/Maze4/Maze5/Maze6/Reception_area/Healthclub_front/Northern_lakefront/Southern_lakefront/Cave_entrance/description
cp descriptions/HallwayS.description Receiving_room/Hallway/description  
cp descriptions/HallwayN.description Receiving_room/Hallway/Hallway/description 
cp descriptions/Healthclub_front.description .Maze2/Maze3/Maze4/Maze5/Maze6/Reception_area/Healthclub_front/description 
cp descriptions/Maze1.description Receiving_room/Hallway/Hallway/Weightroom/Maze1/description 
cp descriptions/Maze3.description .Maze2/Maze3/description 
cp descriptions/Maze4.description .Maze2/Maze3/Maze4/description
cp descriptions/Maze5.description .Maze2/Maze3/Maze4/Maze5/description
cp descriptions/Maze6.description .Maze2/Maze3/Maze4/Maze5/Maze6/description 
cp descriptions/Northern_lakefront.description .Maze2/Maze3/Maze4/Maze5/Maze6/Reception_area/Healthclub_front/Northern_lakefront/description 
cp descriptions/Receiving_room.description Receiving_room/description
cp descriptions/Reception_area.description .Maze2/Maze3/Maze4/Maze5/Maze6/Reception_area/description 
cp descriptions/Sauna.description Receiving_room/Hallway/Sauna/description
cp descriptions/Southern_lakefront.description .Maze2/Maze3/Maze4/Maze5/Maze6/Reception_area/Healthclub_front/Northern_lakefront/Southern_lakefront/description
cp descriptions/Weightroom.description ./Receiving_room/Hallway/Hallway/Weightroom/description
